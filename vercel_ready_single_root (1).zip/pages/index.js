
export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Selamat Datang</h1>
      <p>Halaman utama aplikasi.</p>
    </div>
  );
}
