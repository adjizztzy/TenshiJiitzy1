
export default function Dashboard() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Dashboard</h1>
      <p>Kontrol panel sederhana.</p>
    </div>
  );
}
